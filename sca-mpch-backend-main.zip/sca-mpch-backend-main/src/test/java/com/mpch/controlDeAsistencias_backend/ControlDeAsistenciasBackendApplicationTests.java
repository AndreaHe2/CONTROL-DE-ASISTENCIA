package com.mpch.controlDeAsistencias_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControlDeAsistenciasBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
