package com.mpch.controlDeAsistencias_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlDeAsistenciasBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControlDeAsistenciasBackendApplication.class, args);
	}

}
