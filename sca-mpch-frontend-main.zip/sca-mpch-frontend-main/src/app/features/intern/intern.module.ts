import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { InternRoutingModule } from './intern-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    InternRoutingModule
  ]
})
export class InternModule { }
