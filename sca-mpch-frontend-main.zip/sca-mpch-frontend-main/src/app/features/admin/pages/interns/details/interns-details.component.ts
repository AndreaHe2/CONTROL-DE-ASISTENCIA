import { Component } from '@angular/core';

@Component({
  selector: 'admin-interns-details',
  templateUrl: './interns-details.component.html',
})
export class AdminInternsDetailsComponent {

}
