import { Component } from '@angular/core';

@Component({
  selector: 'admin-certificates-add',
  templateUrl: './certificates-add.component.html',
})
export class AdminCertificatesAddComponent {

}
