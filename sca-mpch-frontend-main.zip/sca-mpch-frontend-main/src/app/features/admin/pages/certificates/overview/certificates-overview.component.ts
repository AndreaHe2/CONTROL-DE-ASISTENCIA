import { Component } from '@angular/core';

@Component({
  selector: 'admin-certificates-overview',
  templateUrl: './certificates-overview.component.html',
})
export class AdminCertificatesOverviewComponent {

}
