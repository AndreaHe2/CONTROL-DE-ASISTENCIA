import { Component } from '@angular/core';

@Component({
  selector: 'admin-assistances-details',
  templateUrl: './assistances-details.component.html',
})
export class AdminAssistancesDetailsComponent {

}
