import { Component } from '@angular/core';

@Component({
  selector: 'admin-assistances-add',
  templateUrl: './assistances-add.component.html',
})
export class AdminAssistancesAddComponent {

}
