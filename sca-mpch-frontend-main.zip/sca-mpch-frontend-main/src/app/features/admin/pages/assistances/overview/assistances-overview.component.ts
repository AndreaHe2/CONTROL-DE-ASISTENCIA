import { Component } from '@angular/core';

@Component({
  selector: 'admin-assistances-overview',
  templateUrl: './assistances-overview.component.html',
})
export class AdminAssistancesOverviewComponent {

}
