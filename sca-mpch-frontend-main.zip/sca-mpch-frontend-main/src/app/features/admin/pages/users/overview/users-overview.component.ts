import { Component } from '@angular/core';

@Component({
  selector: 'admin-users-overview',
  templateUrl: './users-overview.component.html',
})
export class AdminUsersOverviewComponent {

}
