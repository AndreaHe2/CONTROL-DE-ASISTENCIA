import { Component } from '@angular/core';

@Component({
  selector: 'admin-users-details',
  templateUrl: './users-details.component.html',
})
export class AdminUsersDetailsComponent {

}
