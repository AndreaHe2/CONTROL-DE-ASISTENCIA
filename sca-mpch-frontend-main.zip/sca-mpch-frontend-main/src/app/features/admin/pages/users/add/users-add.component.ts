import { Component } from '@angular/core';

@Component({
  selector: 'admin-users-add',
  templateUrl: './users-add.component.html',
})
export class AdminUsersAddComponent {

}
