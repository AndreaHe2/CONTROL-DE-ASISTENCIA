import { Component } from '@angular/core';

@Component({
  selector: 'admin-users-edit',
  templateUrl: './users-edit.component.html',
})
export class AdminUsersEditComponent {

}
