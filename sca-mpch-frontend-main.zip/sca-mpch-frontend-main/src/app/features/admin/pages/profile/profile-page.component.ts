import { Component } from '@angular/core';

@Component({
  selector: 'admin-profile-page',
  templateUrl: './profile-page.component.html',
})
export class AdminProfilePageComponent {

}
