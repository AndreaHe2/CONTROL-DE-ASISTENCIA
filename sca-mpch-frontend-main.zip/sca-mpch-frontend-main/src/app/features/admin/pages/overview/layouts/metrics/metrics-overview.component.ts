import { Component } from '@angular/core';

@Component({
  selector: 'admin-metrics-overview',
  templateUrl: './metrics-overview.component.html',
})
export class AdminMetricsOverviewComponent {

}
