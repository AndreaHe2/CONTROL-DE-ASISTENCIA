import { Component } from '@angular/core';

@Component({
  selector: 'admin-overview-page',
  templateUrl: './overview-page.component.html',
})
export class AdminOverviewPageComponent {

}
