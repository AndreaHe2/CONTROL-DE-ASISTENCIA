import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-stats-overview',
  templateUrl: './stats-overview.component.html',
})
export class AdminStatsOverviewComponent {

}
