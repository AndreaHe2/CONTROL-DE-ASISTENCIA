import { Component } from '@angular/core';

@Component({
  selector: 'admin-main-page',
  templateUrl: './main-page.component.html',
})
export class AdminMainPageComponent {

}
