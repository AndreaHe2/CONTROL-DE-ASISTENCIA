

export interface University {
  idUniversity: string;
  name?: string;
  acronym?: string;
  photo?: string;
  status?: boolean;
}
