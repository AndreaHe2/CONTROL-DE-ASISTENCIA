import { Intern } from './intern.interface';


export interface Certificated {
  idCertificated: string;
  intern: Intern;
  status: boolean;
}
