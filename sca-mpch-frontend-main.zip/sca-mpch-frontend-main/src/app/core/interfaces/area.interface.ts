
export interface Area {
  idArea?: string;
  name?: string;
  nro_vacancies?: number;
  hours_certified?: number;
  status?: boolean;
}
