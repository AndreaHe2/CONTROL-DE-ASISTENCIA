

export interface Role {
  idRole?: string;
  name?: string;
}
